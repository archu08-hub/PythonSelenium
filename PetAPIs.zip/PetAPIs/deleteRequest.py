import pytest


def test_delete_pet(api,base_url):

    pet_id=2
    res = api.delete(f"{base_url}/pet/{pet_id}", timeout=10)
    response_data = res.text

    assert res.status_code == 200


def test_delete_invalid_pet(api,base_url):

    pet_id="invali_id"
    res = api.delete(f"{base_url}/pet/{pet_id}", timeout=10)
    response_data = res.text

    assert res.status_code == 400

