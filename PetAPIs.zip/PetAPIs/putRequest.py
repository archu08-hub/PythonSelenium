import pytest


def test_update_pet_valid(api, base_url):
    valid_payload = {
        "id": 10,
        "category": {"id": 1, "name": "Dogs"},
        "name": "doggie",
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "available",
    }
    valid_res = api.put(f"{base_url}/pet", json=valid_payload, timeout=10)
    assert valid_res.status_code == 200
    assert valid_res.json()["name"] == "doggie"
    print("Request updated")

    def test_update_pet_invalid_id(api, base_url):
        invalid_payload = {"id": "340000"}
        invalid_res = api.put(f"{base_url}/pet", json=invalid_payload, timeout=10)
        assert invalid_res.status_code == 400
        print("Request invalid")

    def test_update_pet_not_found(api, base_url):
        notFound_payload = {"id": 999999, "name": "ghost_dog"}
        notFound_res = api.put(f"{base_url}/pet", json=notFound_payload, timeout=10)
        assert notFound_res .status_code == 404
        print("Request not found")

    def test_update_pet_validation_exception(api, base_url):
        exception_payload = {
            "id": 11,
            "category": {"id": 1, "name": "Dogs"},
            "photoUrls": ["string"],
            "tags": [{"id": 0, "name": "string"}],
            # "name" missing → validation error
            "status": "available",
        }
        exception_res = api.put(f"{base_url}/pet", json=exception_payload, timeout=10)
        assert exception_res.status_code == 422
        print("Exception occurred")