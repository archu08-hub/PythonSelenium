import pytest


@pytest.mark.parametrize("status", ["available", "pending", "sold"])
def test_find_pet_by_status(api, base_url, status):
    res = api.get(f"{base_url}/pet/findByStatus", params={"status": status}, timeout=10)

    assert res.status_code == 200
    response_data = res.json()
    print(response_data)
    print(f"Verified {len(response_data)} pets with status='{status}'")

