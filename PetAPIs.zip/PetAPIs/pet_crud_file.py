import pytest


def test_create_pet(api, base_url):
    pet = {
        "id": 1010,
        "name": "doggie",
        "category": {"id": 1, "name": "Dogs"},
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "available"
    }
    res = api.post(f"{base_url}/pet", json=pet, timeout=10)
    assert res.status_code == 200
    assert res.json()["name"] == "doggie"


def test_get_pet_by_id(api, base_url):
    pet_id = 1010
    res = api.get(f"{base_url}/pet/{pet_id}", timeout=10)
    assert res.status_code == 200
    assert res.json()["id"] == pet_id


def test_update_pet(api, base_url):
    updated_pet = {
        "id": 1010,
        "name": "doggie_updated",
        "category": {"id": 1, "name": "Dogs"},
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "pending"
    }
    res = api.put(f"{base_url}/pet", json=updated_pet, timeout=10)
    assert res.status_code == 200
    assert res.json()["name"] == "doggie_updated"


def test_delete_pet(api, base_url):
    pet_id = 1010
    res = api.delete(f"{base_url}/pet/{pet_id}", timeout=10)
    assert res.status_code == 200

    # Verify pet no longer exists
    res = api.get(f"{base_url}/pet/{pet_id}", timeout=10)
    assert res.status_code == 404
