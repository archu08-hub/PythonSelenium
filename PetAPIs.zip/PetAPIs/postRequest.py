import pytest


def test_create_new_pet(api, base_url):
    new_pet = {
        "id": 10,
        "name": "doggie",
        "category": {"id": 1, "name": "Dogs"},
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "available"
    }

    # post request
    res = api.post(f"{base_url}/pet", json=new_pet, timeout=10)
    # print("New pet created successfully")

    # getting response data in json format
    response_data = res.json()
    # print(response_data)

    assert res.status_code == 200


def test_create_new_pet_invalid_input(api, base_url):
    # Verify invalid id and check validation error
    invalid_pet = {
        "id": "invalid_id",
        "name": "doggie",
        "category": {"id": 1, "name": "Dogs"},
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "available"
    }

    res = api.post(f"{base_url}/pet", json=invalid_pet, timeout=10)
    # print(res.text)
    assert res.status_code == 400


def test_create_new_pet_validation_exception(api, base_url):
    # Missing "name" field to check validation error
    invalid_pet = {
        "id": 11,
        "category": {"id": 1, "name": "Dogs"},
        "photoUrls": ["string"],
        "tags": [{"id": 0, "name": "string"}],
        "status": "available"
    }

    res = api.post(f"{base_url}/pet", json=invalid_pet, timeout=10)
    # print(res.text)
    assert res.status_code == 422
