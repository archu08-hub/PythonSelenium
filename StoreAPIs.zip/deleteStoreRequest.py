import pytest


def test_delete_request_by_orderid(api, base_url):
    order_id = 2
    res = api.delete(f"{base_url}/store/order/{order_id}", timeout=10)
    response_data = res.text

    assert res.status_code == 200


def test_delete_invalid_orderid(api, base_url):
    order_id = "ABC"
    res = api.delete(f"{base_url}/store/order/{order_id}", timeout=10)
    response_data = res.text

    assert res.status_code == 400


def test_delete_notfound_orderid(api, base_url):
    order_id = 99999999990
    res = api.delete(f"{base_url}/store/order/{order_id}", timeout=10)
    response_data = res.text

    assert res.status_code == 404
