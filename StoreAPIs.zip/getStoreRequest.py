import pytest


def test_get_store_inventory_error(api, base_url):
    res = api.get(f"{base_url}/store/inventory", timeout=10)
    assert res.status_code == 500


def test_get_store_inventory(api, base_url):
    inventory_count = {
        "additionalProp1": 0,
        "additionalProp2": 0,
        "additionalProp3": 0
    }
    resp = api.get(f"{base_url}/store/inventory", json=inventory_count, timeout=10)
    assert resp.status_code == 500


def test_get_store_order_by_orderid(api, base_url):
    order_id = 10
    response = api.get(f"{base_url}/store/order/{order_id}", timeout=10)
    assert response.status_code == 200


def test_get_store_invalid_orderid(api, base_url):
    order_id = "{invalid_id}"
    invalid_res = api.get(f"{base_url}/store/order/{order_id}", timeout=10)
    assert invalid_res.status_code == 400


def test_store_order_notfound(api, base_url):
    order_id = 100000
    notfound_res = api.get(f"{base_url}/store/order/{order_id}", timeout=10)
    assert notfound_res.status_code == 404
