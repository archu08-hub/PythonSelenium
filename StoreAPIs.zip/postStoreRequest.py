import pytest


def test_create_new_order(api, base_url):
    new_order = {
        "id": 10,
        "petId": 198772,
        "quantity": 7,
        "shipDate": "2025-08-24T10:24:15.244Z",
        "status": "approved",
        "complete": "true"
    }

    # post request
    res = api.post(f"{base_url}/pet", json=new_order, timeout=10)
    response_data = res.json()
    assert res.status_code == 200


def test_new_order_invalid_input(api, base_url):
    new_order = {
        "id": "abc",
        "petId": 198772,
        "quantity": 7,
        "shipDate": "2025-08-24T10:24:15.244Z",
        "status": "approved",
        "complete": "true"
    }

    # post request
    res = api.post(f"{base_url}/pet", json=new_order, timeout=10)
    response_data = res.json()
    assert res.status_code == 400

def test_new_order_validation_exception(api, base_url):
    new_order = {
        "id": "abc",
        "petId": 198772,
        "quantity": "abc",
        "shipDate": "2025-08-24T10:24:15.244Z",
        "status": "approved",
        "complete": "true"
    }

    # post request
    res = api.post(f"{base_url}/pet", json=new_order, timeout=10)
    response_data = res.json()
    assert res.status_code == 422
