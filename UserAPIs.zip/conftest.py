import pytest
import requests


@pytest.fixture(scope="session", autouse=True)
def base_url():
    return "https://petstore3.swagger.io/api/v3"


@pytest.fixture(scope="session", autouse=True)
def api():
    sess = requests.session()
    sess.headers.update({"Accept": "application/json"})
    return sess
