import pytest


def test_update_user(api, base_url):
    update_user = {
        "id": 10,
        "username": "theUser",
        "firstName": "John",
        "lastName": "James",
        "email": "john@email.com",
        "password": "12345",
        "phone": "12345",
        "userStatus": 1
    }
    username = "user1"
    res = api.put(f"{base_url}/user/{username}", json=update_user, timeout=10)
    assert res.status_code == 200
