import pytest


def test_user_login(api, base_url):
    user_name = "abc"
    pwd = "pwd"
    res = api.get(f"{base_url}/user/login?username={user_name}&password={pwd}", timeout=10)
    assert res.status_code == 200


def test_user_invalid_login(api, base_url):
    user_name = " "
    pwd = "pwd"
    res = api.get(f"{base_url}/user/login?username={user_name}&password={pwd}", timeout=10)
    assert res.status_code == 400
