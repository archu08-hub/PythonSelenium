import pytest


def test_get_user_by_name(api, base_url):
    username = "user1"
    res = api.get(f"{base_url}/user/{username}", timeout=10)
    assert res.status_code == 200


def test_check_invalid_username(api, base_url):
    username = "aa"
    res = api.get(f"{base_url}/user/{username}", timeout=10)
    assert res.status_code == 500
