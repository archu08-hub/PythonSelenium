import pytest


def test_user_logout(api, base_url):
    res = api.get(f"{base_url}/user/logout", timeout=10)
    assert res.status_code == 200
