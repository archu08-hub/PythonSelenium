import pytest


def test_create_user_with_list(api, base_url):
    new_user_list = [
        {
            "id": 10,
            "username": "theUser",
            "firstName": "John",
            "lastName": "James",
            "email": "john@email.com",
            "password": "12345",
            "phone": "12345",
            "userStatus": 1
        }
    ]
    res = api.post(f"{base_url}/user", json=new_user_list, timeout=10)
    assert res.status_code == 200
