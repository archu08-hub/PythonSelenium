import pytest


def test_new_user_creation(api, base_url):
    new_user = {
        "id": 10,
        "username": "theUser",
        "firstName": "John",
        "lastName": "James",
        "email": "john@email.com",
        "password": "12345",
        "phone": "12345",
        "userStatus": 1
    }
    res = api.post(f"{base_url}/user", json=new_user, timeout=10)
    assert res.status_code == 200
