import pytest


def test_delete_user(api, base_url):
    username = "aa"
    res = api.delete(f"{base_url}/user/{username}", timeout=10)
    assert res.status_code == 200


def test_delete_invalid_user(api, base_url):
    username = "aa"
    res = api.delete(f"{base_url}/user/{username}", timeout=10)
    assert res.status_code == 400
