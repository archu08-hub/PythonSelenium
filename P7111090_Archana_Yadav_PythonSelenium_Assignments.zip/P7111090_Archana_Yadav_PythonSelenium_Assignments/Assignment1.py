from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://angular-university.io/")

wait = WebDriverWait(driver, 10)
time.sleep(2)

# Click on Maybe Later button on popup
popup_button = wait.until(EC.element_to_be_clickable((By.ID, "onesignal-slidedown-cancel-button")))
popup_button.click()
print("Dismissed OneSignal popup")
time.sleep(2)

# Click on My Courses
my_courses = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "My Courses")))
my_courses.click()
print("Clicked My Courses link")
time.sleep(2)


# Close the subscription popup
#close_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@class='close' and @aria-label='Close']")))
#close_btn.click()
#print("Closed subscription modal")
#time.sleep(2)

# Click on Angular for Beginners
course = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//div[text()='Angular For Beginners']/ancestor::div[contains(@class,'card')]")))
course.click()
print("Clicked Angular for Beginners link")
time.sleep(2)

# Select the checkbox
print("Trying to click on checkbox")
# Step 1: Find the row containing the exact lesson title text
row = wait.until(EC.presence_of_element_located((
    By.XPATH, "//tr[td//a[contains(text(), 'Angular for Beginners - Helicopter View')]]"
)))


checkbox = row.find_element(By.CSS_SELECTOR, "div.checkbox.disable-text-selection")

driver.execute_script("arguments[0].scrollIntoView();", checkbox)
driver.execute_script("arguments[0].click();", checkbox)

print("Checkbox clicked for: Angular for Beginners - Helicopter View")


# Validate message
login_popup = wait.until(EC.presence_of_element_located((
        By.XPATH, "//div[contains(text(),'Login using Github')]"
    )))
assert "Login using Github" in login_popup.text
print("Login popup appeared as expected")

driver.quit()
