from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import re


driver = webdriver.Firefox()
driver.maximize_window()
wait = WebDriverWait(driver, 15)

try:
    
    driver.get("https://www.jenkins.io")

   
    documentation_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Documentation')]")))
    documentation_btn.click()

    guided_tour_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[text()='Guided Tour']")))
    guided_tour_link.click()

    
    helpful_link = wait.until(EC.element_to_be_clickable(
        (By.XPATH, "//a[@href='#feedback' and @data-bs-toggle='collapse']")))
    helpful_link.click()

    
    yes_radio = wait.until(EC.element_to_be_clickable((By.ID, "h1")))
    yes_radio.click()

    math_text_element = wait.until(EC.visibility_of_element_located((By.ID, "ssTestLabel")))
    math_text = math_text_element.text  # Example: "What is 4 + 3?"
    print(math_text)
    numbers = list(map(int, re.findall(r'\d+', math_text)))
    if 'plus' in math_text:
        answer = sum(numbers)
    else:
        answer = 0

    answer_input = wait.until(EC.element_to_be_clickable((By.ID, "ssTestValue")))
    answer_input.send_keys(str(answer))

    submit_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Submit')]")))
    submit_btn.click()

    thank_you_msg = wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='thank-you-for-your-feedback']")))
    assert "Thank you for your feedback!" in thank_you_msg.text
    print("Feedback submission successful and validated.")

finally:
    driver.quit()
