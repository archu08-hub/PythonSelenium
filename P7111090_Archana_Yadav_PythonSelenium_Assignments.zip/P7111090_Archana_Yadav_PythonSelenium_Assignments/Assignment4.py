from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time


options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
driver.maximize_window()
wait = WebDriverWait(driver, 10)


driver.get("https://weather.com")


try:
    accept_btn = wait.until(EC.element_to_be_clickable((By.ID, "truste-consent-button")))
    accept_btn.click()
except:
    pass  


search_box = wait.until(EC.presence_of_element_located((By.ID, "headerSearch_LocationSearch_input")))
search_box.clear()
search_box.send_keys("Bengaluru")
time.sleep(2)
search_box.send_keys(Keys.DOWN)
search_box.send_keys(Keys.RETURN)


ten_day_tab = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='10 Day']")))
ten_day_tab.click()


more_forecasts = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='More Forecasts']")))
more_forecasts.click()


air_quality_option = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Air Quality Forecast']")))
air_quality_option.click()


aqi_tab = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//h2[text()='All Pollutants']/parent::*//span[text()='Air Quality Index']")))
aqi_tab.click()

)
try:
    message = wait.until(EC.visibility_of_element_located((By.XPATH, "./ancestor::div[contains(@class, 'Popover')]")))
    print("Air Quality Index message displayed:", message.text)
except:
    print("Air Quality Index message not found.")


time.sleep(5)
driver.quit()
