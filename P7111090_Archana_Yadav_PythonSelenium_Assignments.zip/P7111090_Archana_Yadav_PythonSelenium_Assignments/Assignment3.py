from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def test_job_search(driver):
    wait = WebDriverWait(driver, 15)

    driver.get("https://www.ust.com/en/careers")
    original_window = driver.current_window_handle

   
    accept_cookies = wait.until(EC.element_to_be_clickable((By.ID, "onetrust-accept-btn-handler")))
    accept_cookies.click()

    
    careers_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[text()='Careers']")))
    careers_link.click()

    
    open_roles = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[text()='Search our open roles']")))
    open_roles.click()

    
    wait.until(EC.number_of_windows_to_be(2))

    
    for window_handle in driver.window_handles:
        if window_handle != original_window:
            driver.switch_to.window(window_handle)
            break

    print("Switched to new tab:", driver.title)

    
    wait.until(EC.presence_of_element_located((By.XPATH, "//input[@placeholder='Type a job name, role or skill']")))
    search_field = driver.find_element(By.XPATH, "//input[@placeholder='Type a job name, role or skill']")
    search_field.send_keys("test automation")

    
    location_dropdown = driver.find_element(By.XPATH, "//span[contains(@class, 'location-select-text') and text("
                                                      ")='Location']")
    location_dropdown.click()
    # wait.until(EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'Thiruvananthapuram')]"))).click()
    wait.until(EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'Bangalore')]"))).click()

    
    experience_dropdown = driver.find_element(By.XPATH, "//span[contains(text(),'Experience')]")
    experience_dropdown.click()
    wait.until(EC.element_to_be_clickable((By.XPATH, "//input[@type='radio' and @value='4']/parent::label"))).click()

    selected_exp = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".experience-select-text")))
    print("Selected experience displayed:", selected_exp.text)

    
    search_button = driver.find_element(By.XPATH, "//button[contains(@class, 'js-jobs-filter') and contains(., "
                                                  "'SEARCH')]")
    search_button.click()

    
    wait.until(EC.visibility_of_element_located((By.XPATH, "//div[contains(@class,'result-div')]//strong")))
    result_count = driver.find_element(By.XPATH, "//div[contains(@class,'result-div')]//strong").text
    print(f"Found {result_count} job result(s).")
