# main_test.py

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time

from credentials import login_data  #Importing credentials from credentials.py

url = "https://www.saucedemo.com/"

driver = webdriver.Chrome()
driver.maximize_window()
wait = WebDriverWait(driver, 10)

for username, password in login_data.items():
    driver.get(url)

    try:
        wait.until(EC.presence_of_element_located((By.ID, "user-name")))
        driver.find_element(By.ID, "user-name").send_keys(username)
        driver.find_element(By.ID, "password").send_keys(password)
        driver.find_element(By.ID, "login-button").click()
        time.sleep(3)

        if "inventory.html" in driver.current_url:
            print(f"Login successful for user: {username}")
            driver.find_element(By.ID, "react-burger-menu-btn").click()
            wait.until(EC.element_to_be_clickable((By.ID, "logout_sidebar_link"))).click()
        else:
            error_message = driver.find_element(By.CLASS_NAME, "error-message-container").text
            print(f"Login failed for user: {username} - Error: {error_message}")

    except TimeoutException:
        print(f" Timeout while trying to login with user: {username}")
    except Exception as e:
        print(f" Unexpected error for user: {username} - {str(e)}")

driver.quit()
