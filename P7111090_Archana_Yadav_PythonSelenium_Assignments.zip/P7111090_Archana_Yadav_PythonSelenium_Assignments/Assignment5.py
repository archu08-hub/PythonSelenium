from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time


driver = webdriver.Chrome()
driver.maximize_window()
wait = WebDriverWait(driver, 15)

try:
    
    driver.get("https://www.practo.com/")

    
    city_input = wait.until(EC.element_to_be_clickable(
        (By.XPATH, "//input[@placeholder='Search location']")))
    city_input.clear()
    city_input.send_keys("Thiruvananthapuram")
        wait.until(EC.element_to_be_clickable(
        (By.XPATH, "//div[@data-qa-id='omni-suggestion-main' and text()='Thiruvananthapuram']"))).click()

    time.sleep(2) 

        wait.until(EC.element_to_be_clickable(
        (By.XPATH, "//input[@placeholder='Search doctors, clinics, hospitals, etc.' and @value='physician']"))).click()
   

   
    gender_dropdown = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@data-qa-id='doctor_gender_section']")))
    gender_dropdown.click()

       male_option = wait.until(EC.element_to_be_clickable((By.XPATH, "//li[@data-qa-id='male']")))
    male_option.click()

       experience_dropdown = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//div[@data-qa-id='years_of_experience_section']")))
    experience_dropdown.click()

       experience_10plus = wait.until(EC.element_to_be_clickable((By.XPATH, "//li[@data-qa-id='10,9999999']")))
    experience_10plus.click()

   
    all_filters_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='All Filters']")))
    all_filters_button.click()

    
    fees_above_500 = wait.until(EC.element_to_be_clickable((By.XPATH, "//input[@type='radio' and @value='Above ₹500']")))
    fees_above_500.click()

   
    time.sleep(2) 
    
    
        relevance_dropdown = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//span[text()='Relevance']"))
    )
    relevance_dropdown.click()

        experience_sort_option = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable(
            (By.XPATH, "//li[@data-qa-id='experience_years' and .//span[text()='Experience - High to Low']]"))
    )
    experience_sort_option.click()

    time.sleep(3)  

   
    doctors = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".doctor-info")))
    for doc in doctors[:5]: 
        doctor_names = driver.find_elements(By.CSS_SELECTOR, ".doctor-name")
        experiences = driver.find_elements(By.CSS_SELECTOR, "div[data-qa-id='doctor_experience'] > div")
        fees = driver.find_elements(By.CSS_SELECTOR, "span[data-qa-id='consultation_fee']")
        print(f"Name: {doctor_names}, Experience: {experiences}, Fees: {fees}")
finally:
    driver.quit()
