# conftest.py
import pytest
from selenium import webdriver
from selenium.webdriver.edge.service import Service as EdgeService
import os


@pytest.fixture(scope="function")
def driver():
    options = webdriver.EdgeOptions()

    # Point to local driver path
    driver_path = r"D:\Python_selenium\edgedriver_win64\msedgedriver.exe"
    service = EdgeService(executable_path=driver_path)

    driver = webdriver.Edge(service=service, options=options)
    driver.maximize_window()
    yield driver
    driver.quit()
